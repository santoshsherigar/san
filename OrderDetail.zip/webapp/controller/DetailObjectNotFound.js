sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("utg.app.OrderDetail.controller.DetailObjectNotFound", {});
});
