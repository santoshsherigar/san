sap.ui.define([
	"./model/models",
	"./model/formatter",
	"./controller/ListSelector"
], function() {
	"use strict";
});